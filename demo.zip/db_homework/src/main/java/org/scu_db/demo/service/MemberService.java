package org.scu_db.demo.service;

import org.scu_db.demo.model.Member;

import java.util.List;

public interface MemberService {
}
